package com.example.userstories.enums;

public enum Role {
    USER,
    ADMIN
}