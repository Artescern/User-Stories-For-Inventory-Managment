//package com.example.userstories.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import com.example.userstories.service.UserService;
//import com.example.userstories.service.UserServiceImpl;
//
//@Configuration
//public class UserConfig {
//
//    @Bean
//    public UserService userService() {
//        return new UserServiceImpl();
//    }
//}
